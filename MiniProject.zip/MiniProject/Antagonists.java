
public class Antagonists extends Characters
{
    // instance variables - replace the example below with your own
    private boolean dead;
    int health;
  
    public Antagonists(String n, int strength)
    {
        super(n, strength);
        dead = false;
    }
    
    public void die()
    {
        dead = true;
    }
    
    public boolean isDead()
    {
        return dead;
    }
    
    public int getHealth() {
        return health;
    }
    
    public int getStrength() {
        if(getHealth() < 3) {
            return super.getStrength() -1;
        } else {
            return super.getStrength();
        }
    }
    
    public int getWinInfo(Characters c)
    {
        return super.getWinInfo(c);
    }
    
    public void tagline(){
        System.out.println("I will crush you!");}
}
