
public class Empress extends Protagonist
{
    private int health;
    
    public Empress(String n)
    {
        super(n, 5);
        health = 10;
    }
    
    public String getContent(Characters c)
    {
       return super.getContent(c);
    }
  
}
