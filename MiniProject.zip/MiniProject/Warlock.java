
public class Warlock extends Antagonists
{
  private int magic; 
    
    public Warlock(String n, int mmagic){
        super(n, 0);
        magic = mmagic;
    }

    public int getMagic()
    {
        return magic;
    }
    
    public int getStrength()
    {
        return (getMagic() *2) + 2;
    }
    
    public String getDesc(boolean include_strength)
    {
        String desc = "A warlock called " + getName();
        if(include_strength){
            desc += ", their strength is " + getStrength() + ".";
        } else {
            return null; }
            return desc;
    }
}
