import java.util.*;
import java.util.Random;
public class Protagonist extends Characters
{
     // contains empress
    public Protagonist(String n, int pow)
    {
        super(n, 5);
    }
    
    public String getContent(Characters c)
    {
       Random rand = new Random();
       int chance = rand.nextInt(10);
       Scanner scanner = new Scanner(System.in);
       System.out.println("Do you want to randomly browse the items you own?(y/n)");
       String yn = scanner.nextLine();
       if(yn.contains("y")) {
           if(chance<3){
            return "food";
        } else if (chance <7)
        {
            return "magic dust";
        } else{
            return "weapons";
        }
    } else if(yn.contains("n"))
    { return "okay. bye!";}
    else{
        return null; }
    }
    
    public int getWinInfo(Characters c)
    {
        return super.getWinInfo(c);
    }
    
    public void tagline(){
        System.out.println("I will conquer back my kingdom!");}
}
