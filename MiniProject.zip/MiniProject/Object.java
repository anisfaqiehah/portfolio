
public class Object 
{
    // instance variables - replace the example below with your own
    private int weight;
    private int strength_modifier;
    private int health_modifier;

    public Object()
    {
        // initialise instance variables
        weight=0;
        strength_modifier=0;
        health_modifier=0;
    }

    public Object(int wweight, int sstrength_modifier, int hhealth_modifier)
    {
        weight =wweight;
        strength_modifier=sstrength_modifier;
        health_modifier=hhealth_modifier;
    }
    
    public int getWeight()
    {
        return weight;
    }
    
    public int getHealthModifier()
    {
        return health_modifier;
    }
    
    public int getStrengthModifier()
    {
        return strength_modifier;
    }
    
    public void setStrengthModifier(int s)
    {
        strength_modifier=s;
    }
    
    public String getDesc()
    {
        return "An item that weighs " + getWeight() + " ultimate.";
    }
}

