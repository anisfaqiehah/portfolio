import java.util.Random;
public class Farmer extends Deutragonists
{
    // instance variables - replace the example below with your own
    private String item;
    
    public Farmer(String n, int sstrength, String iitem)
    {
        super(n, 2);
        item = iitem;
    }
    
    public Farmer(String n, int sstrength)
    {
        super(n, sstrength);
        Random rand = new Random();
        int chance = rand.nextInt(5);
        if(chance<3){
            item="nothing";
        } else if (chance <7)
        {
            item = "a bunch of baby carrots";
        } else{
            item = "a loaf of bread";
        }
    }
    
    public String ask(Characters c)
    {
        return super.ask(c);
    }
    
    public String getItem()
    {
        return item;
    }
    
    public int getStrength()
    {
        if(getItem().equals("nothing")) {
            return super.getStrength();
        } else if(getItem().equals("a bunch of baby carrots")) {
            return super.getStrength() + 2;
        } else if (getItem().equals("a loaf of bread")) {
            return super.getStrength() + 4;
        } else {
            return 0;
        }
    }
    
    public String getDesc(boolean include_strength)
    {
        String desc = "A farmer called " + getName();
        if(include_strength) {
            desc += " , the item has strength of  " + getStrength() + ".";
        } else { 
            return null;}
            return desc;
    }
}