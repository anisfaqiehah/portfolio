import java.util.Random;
public class Food extends Object
{
    // instance variables - replace the example below with your own
    private int food;

   
    public Food(int ffood)
    {
        // initialise instance variables
        food = ffood;
    }

    public Food()
    {
        Random rand = new Random();
        food = rand.nextInt(15) + 5;
    }
    
    public int getWeight()
    {
        return (int)((float)food/0.25);
    }
    
    public String getDesc()
    {
        return "A" + (food<10? " little" : (food  <15 ? "n adequate amount of" : " lot of")) + " food";
    }
}
