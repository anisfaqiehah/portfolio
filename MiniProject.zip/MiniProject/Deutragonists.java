import java.util.Scanner;
public class Deutragonists extends Characters
{
    // instance variables - replace the example below with your own
  
    public Deutragonists(String n, int strength)
    {
        super(n, strength);
    }

    public String ask(Characters c)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("What item do you have?");
        String ask = scanner.nextLine();
        if(ask.contains("food")){
            return "Can I have that? Thank you.";
        } else if(ask.contains("weapons")){
            return "I need that for war. How much does it cost?";
        } else if(ask.contains("magic dust")) {
            return "What do you need in return?";
        } else {
            return "So you are my enemy!";
        }
        
    }
    
    public String itemUlti(Characters c)
    {
        return super.itemUlti(c);
    }
    
    public void tagline(){
        System.out.println("Save us empress!");}
}
