
public class Ogre extends Antagonists
{
    public Ogre(String n, int pow){
        super(n, 5);
    }

}
