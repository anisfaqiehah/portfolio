import java.util.Scanner;
import java.util.Random;

public class Start
{
    private static String[] names = {"A", "B", "C", "D", "E", "F", "G", "H","I", "J"};
    private static int name_index=0;
    
    // creating player as the Empress
    public static Empress createEmp()
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Hello. Enter your game name");
        String name = scanner.nextLine();
        return new Empress(name);
    }

    // creating Fairy from Deutragonists
    public static Fairy createFairy()
    {
        // put your code here
        Random rand = new Random();
        if(rand.nextInt(10) > 5) {
            return null;
        } else { 
            Fairy fairy = new Fairy(names[name_index], rand.nextInt(5));
            name_index++;
            return fairy;
        }
    }
    
    // creating Farmer from Deutragonists
    public static Farmer createFarmer()
    {
        // put your code here
        Random rand = new Random();
        if(rand.nextInt(10) > 5) {
            return null;
        } else { 
            Farmer farmer = new Farmer(names[name_index], rand.nextInt(5));
            name_index++;
            return farmer;
        }
    }
    
    // creating Bladesmith from Deutragonists
    public static Bladesmith createBS()
    {
        // put your code here
        Random rand = new Random();
        if(rand.nextInt(10) > 5) {
            return null;
        } else { 
            Bladesmith bs = new Bladesmith(names[name_index], rand.nextInt(5));
            name_index++;
            return bs;
        }
    }
    
    // creating Warlock from Antragonists
    public static Warlock createWarlock()
    {
        Random rand = new Random();
        if(rand.nextInt(10) > 5) {
            return null;
        } else {
            Warlock warlock = new Warlock(names[name_index], rand.nextInt(3));
            name_index++;
            return warlock;
        }
    }
    
      // creating Robot from Antragonists
    public static Robot createRobot()
    {
        Random rand = new Random();
        if(rand.nextInt(10) > 5) {
            return null;
        } else {
            Robot robot = new Robot(names[name_index], rand.nextInt(3));
            name_index++;
            return robot;
        }
    }
   
    // creating Ogre from Antragonists
    public static Ogre createOgre()
    {
        Random rand = new Random();
        if(rand.nextInt(10) > 5) {
            return null;
        } else {
            Ogre ogre = new Ogre(names[name_index], rand.nextInt(3));
            name_index++;
            return ogre;
        }
    }
    
    public static Magic createMagic()
    {
            return new Magic(3);
    }
    
    public static Food createFood()
    {
            return new Food(3);
    }
    
    public static Weapon createWeapon()
    {
            return new Weapon();
    }
    
    public static String inputString (String message)
    {
       String answer;
       Scanner scanner = new Scanner(System.in);

       System.out.println(message);
       answer = scanner.nextLine();
   
       return answer;
    } // END inputString
    
    public static void printDet()
    {
        String ans = inputString("What do you want to know about?(Pick warlock/fairy/robot/farmer/ogre/bladesmith)");
        if(ans.equals("warlock")) //using if statement to decide an agent can heal or not
        {
            System.out.println("Warlock can cast spells on you and is an enemy. You must fight warlock!");
        }
        else if(ans.equals("robot")) //using if statement to decide an agent can heal or not
        {
            System.out.println("Robot can kill you relentlessly and is an enemy. You must fight robot!");
        }
        else if(ans.equals("ogre")) //using if statement to decide an agent can heal or not
        {
            System.out.println("Ogre is generally very angry and is an enemy. You must fight ogre!");
        }
        else if(ans.equals("farmer")) //using if statement to decide an agent can heal or not
        {
            System.out.println("Farmer can help you by giving you food. Farmer is a friend!");
        }
         else if(ans.equals("fairy")) //using if statement to decide an agent can heal or not
        {
            System.out.println("Fairy can help you by giving you magic dust. Fairy is a friend!");
        }
         else if(ans.equals("bladesmith")) //using if statement to decide an agent can heal or not
        {
            System.out.println("Bladesmith can supply you with swords/arrows/any weapons you need. Bladesmith is a friend!");
        }
        else 
        {
            System.out.println("I don't quite get that. Please try again!");
        }

        return;
    }
    
    public static void main(String[] main)
    {
        Scanner scanner = new Scanner(System.in);
    
        System.out.println("Get ready for the adventure of your life.");
        System.out.println(" ----------------------------------");
        System.out.println();
        
        Empress empress = createEmp();
        Warlock warlock = createWarlock();
        Fairy fairy = createFairy();
        Farmer farmer = createFarmer();
        Bladesmith bladesmith = createBS();
        Robot robot = createRobot();
        Ogre ogre = createOgre();
        
        System.out.println();
        System.out.println("Hello " + empress.getName() + "!");
        System.out.println();
        System.out.println("Your task is to conquer back your kingdom by fighting enemies and seek help!");
        System.out.println();
        
        printDet();
        Characters ep;
        ep=new Protagonist(empress.getName(), 10);  // substitute principle
        ep.tagline(); //application of polymorphism - late binding
        Characters wl = new Antagonists(warlock.getName(), 6); // substitute principle
        wl.tagline(); //application of polymorphism - late binding
        Characters rb = new Antagonists(robot.getName(), 8); // substitute principle
        rb.tagline(); //application of polymorphism - late binding
        Characters og = new Antagonists(ogre.getName(), 2); // substitute principle
        og.tagline(); //application of polymorphism - late binding
        Characters fy = new Deutragonists(fairy.getName(), 5); // substitute principle
        fy.tagline(); //application of polymorphism - late binding
        Characters fm = new Deutragonists(farmer.getName(), 5); // substitute principle
        fm.tagline(); //application of polymorphism - late binding
        Characters bs = new Deutragonists(bladesmith.getName(), 5); // substitute principle
        bs.tagline(); //application of polymorphism - late binding
        
        Object mg = new Magic(); // substitute principle
        mg.getDesc(); //application of polymorphism - late binding
        Object fd = new Food(); // substitute principle
        fd.getDesc(); //application of polymorphism - late binding
        Object wp = new Weapon(); // substitute principle
        wp.getDesc(); //application of polymorphism - late binding
        
        
        
        
        
        System.out.println("GAME OVER!");
 }
}
           
