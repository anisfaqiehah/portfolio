import java.util.Scanner;
import java.util.Random;
public class Characters
{
    private String name;
    private int strength;

    public Characters(String n, int sstrength)
    {
        // initialise instance variables
        name = n;
        strength = sstrength;
    }
    
    public int getStrength()
    {
        return strength;
    }
    
    public String getName()
    {
        return name;
    }
    
    public int getWinInfo(Characters c)
    {
        System.out.println("Will you win... ");
        int random_win = new Random().nextInt(10);
        if(random_win == 0) {
            return 0;
        } else if(random_win >0) {
            return 1; 
        } else { 
            return -1; }
    }
    
    public String itemUlti(Characters c)
    {
        System.out.println("The item possibly has " );
        int num = new Random().nextInt(10);
        if(num == 0) {
            return " 0 points" ;
        } else if(num >0) {
            return " 5 points" ; 
        } else { 
            return " no points"; }
    }
    
    public void tagline(){
        System.out.println("I will win!");}
}
