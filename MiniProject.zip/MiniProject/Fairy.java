import java.util.Random;
public class Fairy extends Deutragonists
{
    // instance variables - replace the example below with your own
    private String item;
    
    public Fairy(String n, int sstrength, String iitem)
    {
        super(n, 2);
        item = iitem;
    }
    
    public Fairy(String n, int sstrength)
    {
        super(n, sstrength);
        Random rand = new Random();
        int chance = rand.nextInt(5);
        if(chance<3){
            item="nothing";
        } else{
            item = "magic dust";
        }
    }
    
    public String ask(Characters c)
    {
        return super.ask(c);
    }
    
    public String getItem()
    {
        return item;
    }
    
    public int getStrength()
    {
        if(getItem().equals("nothing")) {
            return super.getStrength();
        } else if(getItem().equals("magic dust")) {
            return super.getStrength() + 2;
        } else {
            return 0;
        }
    }
    
    public String getDesc(boolean include_strength)
    {
        String desc = "A fairy called " + getName();
        if(include_strength) {
            desc += " , the item has strength of  " + getStrength() + ".";
        } else { 
            return null;}
            return desc;
    }
}