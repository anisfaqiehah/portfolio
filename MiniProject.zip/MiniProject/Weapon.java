import java.util.Random;

public class Weapon extends Object

{
    // instance variables - replace the example below with your own
    private String type;
    private int strength_modifier;

    public Weapon()
    {
        // initialise instance variables
        Random rand = new Random();
        int chance = rand.nextInt(10);
        if(chance < 5) {
            type = "sword";
            setStrengthModifier(4);
        } else if (chance <7) {
            type = "arrow";
            setStrengthModifier(3);
        } else{
            type = "butter knife";
            setStrengthModifier(1);
        }
    }

    public String getType()
    {
        return type;
    }
    
    public String getDesc()
    {
        return "A " + getType() + ".";
    }
}
