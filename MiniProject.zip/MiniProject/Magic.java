import java.util.Random;
public class Magic extends Object
{
    // instance variables - replace the example below with your own
    private int magic;

   
    public Magic(int mmagic)
    {
        // initialise instance variables
        magic = mmagic;
    }

    public Magic()
    {
        Random rand = new Random();
        magic = rand.nextInt(15) + 5;
    }
    
    public int getWeight()
    {
        return (int)((float)magic/0.25);
    }
    
    public String getDesc()
    {
        return "A" + (magic<10? " little" : (magic  <15 ? "n adequate amount of" : " lot of")) + " magic dust";
    }
}
