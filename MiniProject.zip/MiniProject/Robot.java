
public class Robot extends Antagonists
{
    public Robot(String n, int pow){
        super(n, 5);
    }

}
